from django.core.exceptions import PermissionDenied
from rest_framework.permissions import BasePermission
from rest_framework.authtoken.models import Token


class CheckPermissions(BasePermission):
    def has_permission(self, request, view):
        auth_token = request.headers.get("Authorization")
        try:
            token = Token.objects.get(key = auth_token)
        except Token.DoesNotExist:
            raise PermissionDenied()
        request.user = token.user
        return True
    

class MerchantStatus(BasePermission):
    def has_permission(self, request, view):
        if request.method == 'GET':
            return True
        
        if not request.user.is_merchant:
            raise PermissionDenied()
        
        return True
            
class IsMerchantUser(BasePermission):
    def has_permission(self, request, view):

        if not request.user.is_merchant:
            raise PermissionDenied()
        
        return True

