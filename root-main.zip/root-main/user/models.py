from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.utils.translation import gettext_lazy as _
from root.abstract_models import TimeStamp
from user.manager import CustomUserManager,CustomerManager, MerchantManager
from django.db.models.signals import post_save
from django.dispatch import receiver



class CustomUser(AbstractBaseUser, PermissionsMixin, TimeStamp):
    user_id = models.BigAutoField(primary_key=True)
    user_name = models.CharField(max_length = 225)
    email = models.EmailField(_("Email"), unique=True)
    is_staff = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    is_customer = models.BooleanField(default = True)
    is_merchant = models.BooleanField(default = False)


    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["user_name"]

    objects = CustomUserManager()

    def save(self, *args, **kwargs):
        if not self.pk:
            self.user_name = str(self.email.split("@")[0])
        super(CustomUser, self).save(*args, **kwargs)
        

    def __str__(self):
        return self.email

 
class Customer(CustomUser):
    objects = CustomerManager()
    
    class Meta:
        proxy = True
    def save(self, *args, **kwargs):
        self.is_customer = True
        return super().save(*args, **kwargs)
        
class Merchant(CustomUser):
    objects = MerchantManager()
    class Meta:
        proxy = True
    def save(self, *args, **kwargs):
        self.is_merchant = True
        return super().save(*args, **kwargs)
    
class MerchantProfile(TimeStamp):
    user = models.OneToOneField(CustomUser, on_delete = models.CASCADE, related_name = "merchant_profile" )


    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Merchant Profile'
        verbose_name_plural = 'Merchant Profiles'

    def __str__(self):
        return self.user.user_name
    

@receiver(post_save, sender = CustomUser)
def create_merchantProfile(sender, instance = None, created = None, **kwargs):
    if instance.is_merchant is True:
        MerchantProfile.objects.get_or_create(user = instance)
    




