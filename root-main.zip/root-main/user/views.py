from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required

def login(request):
    return render(request,'login.html')
    #HttpResponse('login successfull')

@login_required
def home(request):
    return render(request,'home.html')
    #return HttpResponse('Welcome')



'''
from django.shortcuts import render
from django.http import HttpResponse
import requests

def oauth2_callback(request):
    # Step 1: Obtain authorization code from the request
    authorization_code = request.GET.get('code')

    # Step 2: Exchange authorization code for tokens
    token_url = "https://www.googleapis.com/oauth2/v4/token"
    client_id = "475249051293-tdc0h1g2apli83dctj8ri9ji80rcj6i7.apps.googleusercontent.com"
    client_secret = "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"
    redirect_uri = "http://127.0.0.1:8000/social-auth/complete/google-oauth2/"

    payload = {
        'code': authorization_code,
        'client_id': client_id,
        'client_secret': client_secret,
        'redirect_uri': redirect_uri,
        'grant_type': 'authorization_code'
    }

    response = requests.post(token_url, data=payload)
    tokens = response.json()

    # Step 3: Use access token with /convert-token endpoint
    access_token = tokens['access_token']
    convert_token_url = "https://example.com/convert-token"

    convert_token_payload = {
        'token': access_token,
        # Additional parameters if required by the endpoint
    }

    # Make request to /convert-token endpoint
    convert_token_response = requests.post(convert_token_url, data=convert_token_payload)
    print("convert_token_response",convert_token_response)
    # Process the response from /convert-token endpoint
    # Do something with the converted token

    return HttpResponse("OAuth2 flow completed successfully!")

'''


'''from django.http import JsonResponse
from rest_framework.views import APIView
from google.oauth2 import id_token
from google.auth.transport import requests as google_requests
from django.conf import settings

class GoogleAuthAPIView(APIView):
    def post(self, request):
        id_token_str = request.data.get('id_token')
        print("id_token_str",id_token_str)
        try:
            # Verify the ID token with Google
            id_info = id_token.verify_oauth2_token(
                id_token_str, google_requests.Request(), settings.GOOGLE_CLIENT_ID)

            # Get the user's Google ID
            google_user_id = id_info['sub']

            # Get the access token
            access_token = id_info['access_token']

            return JsonResponse({'google_user_id': google_user_id, 'access_token': access_token})
        except ValueError as e:
            # Invalid token
            return JsonResponse({'error': 'Invalid token'}, status=400)
'''

from django.shortcuts import redirect
from google_auth_oauthlib.flow import Flow
from google.oauth2.credentials import Credentials

from django.conf import settings

from django.shortcuts import redirect
from google_auth_oauthlib.flow import Flow
from google.oauth2.credentials import Credentials

from django.conf import settings
import urllib.parse

def google_drive_auth(request):
    flow = Flow.from_client_config(
        {
            'web': {
                'client_id': settings.GOOGLE_DRIVE_CLIENT_ID,
                'client_secret': settings.GOOGLE_DRIVE_CLIENT_SECRET,
                'redirect_uris': [settings.GOOGLE_DRIVE_REDIRECT_URI],
                'auth_uri': 'https://accounts.google.com/o/oauth2/auth',
                'token_uri': 'https://accounts.google.com/o/oauth2/token',
            }
        },
        scopes=['https://www.googleapis.com/auth/drive'],
    )

    authorization_url, state = flow.authorization_url(
        access_type='offline',
        include_granted_scopes='true'
    )

    # Encode redirect_uri to ensure proper formatting
    redirect_uri = urllib.parse.quote_plus(settings.GOOGLE_DRIVE_REDIRECT_URI)
    
    # Add redirect_uri to the authorization URL
    authorization_url_with_redirect_uri = f"{authorization_url}&redirect_uri={redirect_uri}"

    request.session['google_auth_state'] = state

    return redirect(authorization_url_with_redirect_uri)


from django.shortcuts import redirect
from google_auth_oauthlib.flow import Flow
from google.oauth2.credentials import Credentials

from django.conf import settings

def google_drive_auth_callback(request):
    state = request.session.get('google_auth_state', None)
    flow = Flow.from_client_config(
        {
            'web': {
                'client_id': settings.GOOGLE_DRIVE_CLIENT_ID,
                'client_secret': settings.GOOGLE_DRIVE_CLIENT_SECRET,
                'redirect_uris': [settings.GOOGLE_DRIVE_REDIRECT_URI],
                'auth_uri': 'https://accounts.google.com/o/oauth2/auth',
                'token_uri': 'https://accounts.google.com/o/oauth2/token',
            }
        },
        scopes=['https://www.googleapis.com/auth/drive'],
        state=state
    )

    # Build absolute URI with HTTPS to avoid InsecureTransportError
    redirect_uri = request.build_absolute_uri('/auth/google-drive/callback/')
    print("redirect_uri",redirect_uri)
    #authorization_response = request.build_absolute_uri()
    flow.fetch_token(authorization_response=redirect_uri)
    #flow.fetch_token(authorization_response=authorization_response)

    credentials = flow.credentials
    print("Access Token:", credentials.t)
    # Save the credentials to use later for API requests
    # For example, you can save them to the database associated with the current user
    #return HttpResponse('login successfull')
    return redirect('/')

