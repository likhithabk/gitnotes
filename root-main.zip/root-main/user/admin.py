from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from user.forms import CustomUserCreationForm, CustomUserChangeForm
from user.models import CustomUser, MerchantProfile


# Register your models here.
@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    add_form = CustomUserCreationForm
    form = CustomUserChangeForm
    model = CustomUser
    list_display = ["user_name", "is_customer", "is_merchant"]
    # list_filter = ["is_customer", "is_merchant"]
    fieldsets = (
        (None, {"fields": ("email", "password")}),
        ("Permissions", {"fields": ("is_staff", "is_active")}),
        ("User_Type", {"fields": ("is_customer", "is_merchant")})
    )

    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide"),
                "fields": ("email", "password1", "password2", "is_staff", "is_active"),
            },
        ),
    )
    search_fields = ("user_name",)
    ordering = ("email",)





# admin.site.register(MerchantProfile)
