from django.db import models
from ind_cat_fun_but.models import Category, Function, FunctionButton
from root.abstract_models import TimeStamp, AbstractShop, AbstractProduct

# Create your models here.

class Shop(AbstractShop):


    category = models.ForeignKey(Category, on_delete = models.DO_NOTHING, related_name = 'shop_category')
    function = models.ForeignKey(Function, on_delete = models.DO_NOTHING, related_name = 'shop_function')
    
    class Meta:
        db_table = "shops"
        ordering = ["-created_at"]

    def __str__(self):
        #return self.name
        return '__all__'
    


class Product(AbstractProduct):
    func_but = models.ForeignKey(FunctionButton ,on_delete = models.DO_NOTHING, related_name = 'pro_fun_but')
    # variant = models.CharField(max_length = 225, null = True, blank = True)
    # variant_price = models.IntegerField(default = 0, blank = True, null = True)
    shop = models.ForeignKey(Shop, null = True, blank = True ,on_delete = models.CASCADE, related_name = "products" )

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Product'
        verbose_name_plural = 'Products'

    def __str__(self) -> str:
        return self.name