from django.contrib import admin
from shop_prod.models import Shop, Product

# Register your models here.

@admin.register(Shop)
class ShopAdmin(admin.ModelAdmin):
    list_display = ["name", "favourite_count","live_views","views", "shop_id", "created_at"]
    search_fields = ["name"]
    list_filter = ["is_active" , "is_open"]

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ["name", "price", "max_order_qty", "product_id", "created_at"]
    search_fields = ["name","shop"]
    list_filter = ["shop", "in_stock"]