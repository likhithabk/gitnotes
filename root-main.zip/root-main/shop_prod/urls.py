from django.urls import path, include
from rest_framework.routers import SimpleRouter
from shop_prod.views import ShopViewset, ProductViewset

router = SimpleRouter()
router.register("",ShopViewset, basename= "" )
router.register("", ProductViewset, basename= "")



urlpatterns = [
    path("", include(router.urls))
]

'''from django.urls import path
from shop_prod.views import ShopListCreateAPIView


urlpatterns = [
    path('get_shop/', ShopListCreateAPIView.as_view(), name='shop-list-create'),
]'''
