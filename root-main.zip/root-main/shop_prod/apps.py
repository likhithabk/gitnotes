from django.apps import AppConfig


class ShopProdConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shop_prod'
