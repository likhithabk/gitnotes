from django.urls import path, include
from rest_framework.routers import SimpleRouter
from cart_hist_paym.views import CartViewset, HistoryViewset, PaymentViewset

router = SimpleRouter()
router.register ("", PaymentViewset, basename= "")
router.register("", HistoryViewset, basename= "")
router.register("", CartViewset, basename= "")


urlpatterns = [
    path("", include(router.urls))
]