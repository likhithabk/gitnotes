from django.shortcuts import render
from rest_framework import viewsets
from cart_hist_paym.models import Cart, History, Payment
from cart_hist_paym.serializers import CartSerializer, HistorySerializer, PaymentSerializer

# Create your views here.

class CartViewset(viewsets.ModelViewSet):
    queryset = Cart.objects.all()
    serializer_class = CartSerializer


class HistoryViewset(viewsets.ModelViewSet):
    queryset = History.objects.all()
    serializer_class = HistorySerializer


class PaymentViewset(viewsets.ModelViewSet):
    queryset = Payment.objects.all()
    serializer_class = PaymentSerializer
