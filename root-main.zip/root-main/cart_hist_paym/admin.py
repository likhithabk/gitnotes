from django.contrib import admin
from cart_hist_paym.models import Cart, History, Payment

# Register your models here.

@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = ["cart_id", "no_of_items", "total_price"]
    search_fields = ["cart_id"]
    list_filter = ["shop_id"]


@admin.register(History)
class HistoryAdmin(admin.ModelAdmin):
    list_display = ["order_id","is_dineIn","is_takeaway","qty", "total_price", "created_at"]
    search_fields = ["order_id"]
    list_filter = ["is_accepted", "is_ready", "is_cancelled", "is_successful"]


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
     list_display = ["payment_id", "created_at" ]
     search_fields = ["payment_id", "order_id"]
     list_filter = ["is_refund", "is_pending", "is_successful"]

