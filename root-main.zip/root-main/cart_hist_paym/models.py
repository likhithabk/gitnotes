from django.db import models
from root.abstract_models import TimeStamp
from shop_prod.models import Product, Shop

# Create your models here.

class Cart(TimeStamp):
    cart_id = models.BigAutoField(primary_key = True)
    # customer_id
    shop_id = models.ForeignKey(Shop, on_delete = models.DO_NOTHING, related_name = 'cart_shop')
    product_id = models.ForeignKey(Product, on_delete = models.DO_NOTHING, related_name = 'cart_product')
    no_of_items = models.PositiveIntegerField(default = 1)
    total_price = models.DecimalField(max_digits = 10, decimal_places = 2, default = 0.0)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Cart'
        verbose_name_plural = 'Carts'

    def __str__(self):
        return str(self.cart_id)



class History(TimeStamp):
    order_id = models.BigAutoField(primary_key= True)
    # customer_id
    shop_id = models.ForeignKey(Shop, on_delete = models.DO_NOTHING, related_name = 'customer_history')
    product_id = models.ForeignKey(Product, on_delete = models.DO_NOTHING, related_name = 'history_product')
    # time
    qty = models.PositiveIntegerField()
    price = models.PositiveIntegerField()
    total_price = models.DecimalField(max_digits = 10, decimal_places = 2, default = 0.0)
    is_dineIn = models.BooleanField(default = False)
    is_takeaway = models.BooleanField(default = False)
    is_accepted = models.BooleanField(default = False)
    is_ready = models.BooleanField(default = False)
    is_cancelled = models.BooleanField(default = False)
    is_successful = models.BooleanField(default = False)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = 'History'
        verbose_name_plural = "Histories"

    def __str__(self):
        return str(self.order_id)


class Payment(TimeStamp):
    payment_id = models.BigAutoField(primary_key=True)
    order_id = models.ForeignKey(History, on_delete = models.DO_NOTHING, related_name = 'payment_id')
    shop_id = models.ForeignKey(Shop, on_delete = models.DO_NOTHING, related_name = 'shop_payment')
    is_refund = models.BooleanField(default = False)
    is_pending = models.BooleanField(default = False)
    is_successful = models.BooleanField(default = False)
    # customer_id

    class Meta:
        ordering = ["-created_at"]
        verbose_name = 'Payment'
        verbose_name_plural = 'Payments'


    def __str__(self):
        return str(self.payment_id)
