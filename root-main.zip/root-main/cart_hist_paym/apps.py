from django.apps import AppConfig


class CartHistPaymConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cart_hist_paym'
