from django.shortcuts import render
from rest_framework import viewsets
from ind_cat_fun_but.models import Industry, Category, Function, FunctionButton
from ind_cat_fun_but.serializers import IndustrySerializer, CategorySerializer, FunctionSerializer, FunctionButtonSerializer

# Create your views here.

class IndustryViewset(viewsets.ModelViewSet):
    queryset = Industry.objects.all()
    serializer_class = IndustrySerializer


class CategoryViewset(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class FunctionViewset(viewsets.ModelViewSet):
    queryset = Function.objects.all()
    serializer_class = FunctionSerializer


class FunctionButtonViewset(viewsets.ModelViewSet):
    queryset = FunctionButton.objects.all()
    serializer_class = FunctionButtonSerializer


