from django.urls import path, include
from rest_framework.routers import SimpleRouter
from ind_cat_fun_but.views import IndustryViewset, CategoryViewset, FunctionViewset, FunctionButtonViewset



router = SimpleRouter()
router.register("", FunctionButtonViewset, basename="")
router.register("", FunctionViewset, basename= "")
router.register("", CategoryViewset, basename= "")
router.register("", IndustryViewset, basename= "")


urlpatterns = [
    path("", include(router.urls))
]

