from django.contrib import admin
from ind_cat_fun_but.models import Industry, Category, Function, FunctionButton

# Register your models here.

@admin.register(Industry)
class IndustryAdmin(admin.ModelAdmin):
    list_display = ["name","industry_id"]
    list_filter = ["is_active"]


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ["name","category_id"]
    list_filter = ["industry", "is_active"]


@admin.register(Function)
class FunctionAdmin(admin.ModelAdmin):
    list_display = [ "name", "function_id"]
    list_filter = ["is_active"]

@admin.register(FunctionButton)
class FunButAdmin(admin.ModelAdmin):
    list_display = [ "name","function_button_id"]
    list_filter = ["function", "is_active"]
   
