from django.db import models
from root.abstract_models import TimeStamp

# Create your models here.

class Industry (TimeStamp):
    industry_id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length = 225, unique = True)
    is_active = models.BooleanField(default = False)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Industry'
        verbose_name_plural = 'Industries'

    def __str__(self):
        return self.name
    
    
class Category(TimeStamp):
    category_id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length = 225, unique = True)
    is_active = models.BooleanField(default = False)
    industry = models.ForeignKey(Industry, on_delete = models.DO_NOTHING, related_name = 'industry')
   
    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Category'
        verbose_name_plural = 'Categories'

    def __str__(self):
        return self.name
    

class Function(TimeStamp):
    function_id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length = 225, unique = True)
    is_active = models.BooleanField(default = False)

    class Meta:
         ordering = ["-created_at"]
         verbose_name = 'Function'
         verbose_name_plural = 'Functions'

    def __str__(self):
        return self.name

class FunctionButton(TimeStamp):
    function_button_id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length = 225, unique = True)
    function = models.ForeignKey(Function, on_delete = models.DO_NOTHING, related_name = 'function')
    is_active = models.BooleanField(default = False)


    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Function Button'
        verbose_name_plural = 'Function Buttons'


    def __str__(self):
        return self.name