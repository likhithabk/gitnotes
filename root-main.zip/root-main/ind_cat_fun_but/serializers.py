from rest_framework import serializers
from ind_cat_fun_but.models import Industry, Category,Function,FunctionButton


class IndustrySerializer(serializers.ModelSerializer):
    class Meta:
        model = Industry
        fields = "__all__"


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = "__all__"

class FunctionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Function
        fields = "__all__"


class FunctionButtonSerializer(serializers.ModelSerializer):
    class Meta:
        model = FunctionButton
        fields = "__all__"
        