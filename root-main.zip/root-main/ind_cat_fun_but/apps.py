from django.apps import AppConfig


class IndCatFunButConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ind_cat_fun_but'
