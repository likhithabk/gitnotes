from django.db import models


class TimeStamp(models.Model):
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)

    class Meta:
        abstract = True

class AbstractShop(TimeStamp):
    shop_id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length = 1000)
    latitude = models.DecimalField(max_digits = 22, decimal_places = 16, default = 0.0)
    longitude = models.DecimalField(max_digits = 22, decimal_places = 16, default = 0.0)
    address = models.TextField( max_length = 500, default = '')
    state = models.CharField(max_length = 225, default = "Tamil Nadu")
    city = models.CharField(max_length = 225, default = "Chennai")
    is_open = models.BooleanField(default = False)
    is_active = models.BooleanField(default = False)
    Info = models.TextField(blank = True, null = True)
    views = models.PositiveIntegerField(default = 0)
    live_views = models.PositiveIntegerField(default = 0)
    favourite_count = models.PositiveIntegerField(default = 0)
    shop_image = models.ImageField(upload_to="root/images/shop")

    class Meta:
        abstract = True

class AbstractProduct(TimeStamp):
    product_id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length = 225)
    max_order_qty = models.IntegerField(default = 1)
    price = models.DecimalField(max_digits = 9, decimal_places = 2)
    description = models.TextField(blank = True, null = True)
    in_stock = models.BooleanField(default = False)
    product_image = models.ImageField(upload_to= "root/images/product")

    class Meta:
        abstract = True